package createUser;

import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchWindowException;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import ObjectPropertiesUtils.readDataFromPropertyFile;
import browserUtils.browserInitilizer;
import excelUtils.readDataFromExcel;
import frameworkUtils.reusableComponent;
import seleniumUtils.seleniumActions;

public class upload {
	private static final Logger logger = Logger.getLogger(createUser.class);
	@BeforeTest
	public static void launchBrowser() throws Exception
	{
		
			browserInitilizer.readDriverUtils(reusableComponent.uploadURL);
			logger.info("im using the url "  +reusableComponent.uploadURL);
		
		
		
	}	
	
	
	@Test(priority = 1 )
	public static void handleAlert() throws Exception {
		seleniumActions.uploadFile();
		
	 }
	

	
	@AfterTest
	public void closeBrowser()
	{
		browserInitilizer.driver.close();
	}
}
