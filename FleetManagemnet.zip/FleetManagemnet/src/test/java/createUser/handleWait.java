package createUser;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import ObjectPropertiesUtils.readDataFromPropertyFile;
import browserUtils.browserInitilizer;
import excelUtils.readDataFromExcel;
import frameworkUtils.reusableComponent;
import seleniumUtils.seleniumActions;

public class handleWait {

	@BeforeTest
	public static void launchBrowser() throws Exception
	{
		browserInitilizer.readDriverUtils(reusableComponent.waiturl);
		String title = browserInitilizer.driver.getTitle();
		System.out.println(title);
	}
	
	
	@Test(priority = 1 )
	public static void handlewaitforselenium() throws Exception {
		
		seleniumActions.click("//button[@id='btn1']");
		seleniumActions.ImplicitWait(10);
		seleniumActions.sendkeys("(//input[@id='txt1'])[1]","aaaaa");
		
		
	 }
	
	@Test(priority = 2 )
	public static void explicitWait() throws Exception {
		
		seleniumActions.click("//button[@id='btn2']");
		seleniumActions.ExplictWait(15,"(//input[@id='txt2'])[1]");
		seleniumActions.sendkeys("(//input[@id='txt2'])[1]","aaaaa");
		
		
	 }
	
	@AfterTest
	public void closeBrowser()
	{
		browserInitilizer.driver.quit();
	}
}
