package createUser;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import ObjectPropertiesUtils.readDataFromPropertyFile;
import browserUtils.browserInitilizer;
import excelUtils.readDataFromExcel;
import frameworkUtils.reusableComponent;
import seleniumUtils.seleniumActions;

public class handleAlert {
	private static final Logger logger = Logger.getLogger(createUser.class);
	@BeforeTest
	public static void launchBrowser() throws Exception
	{
		browserInitilizer.readDriverUtils(reusableComponent.alerturl);
		logger.info("im using the url "  +reusableComponent.alerturl);
	}
	
	
	@Test(priority = 1 )
	public static void handleAlert() throws Exception {
		seleniumActions.click("//input[@name='submit']");
	String msg  =seleniumActions.alertsActions(true);
	logger.info("my alert msg is " + msg);
	 }
	

	
	@AfterTest
	public void closeBrowser()
	{
		browserInitilizer.driver.close();
	}
}
