package createUser;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import browserUtils.browserInitilizer;
import frameworkUtils.reusableComponent;
import seleniumUtils.seleniumActions;

public class handlewindow {

	@BeforeTest
	public static void launchBrowser() throws Exception
	{
		browserInitilizer.readDriverUtils(reusableComponent.Switch_window_url);
		String title = browserInitilizer.driver.getTitle();
		System.out.println(title);
	}
	
	
	@Test(priority = 1 )
	public static void handleMultiwindow() throws Exception {
		
		seleniumActions.switToNewWindow();
		
		
	 }
	
	
	
	@AfterTest
	public void closeBrowser()
	{
		//browserInitilizer.driver.quit();
	}
}
