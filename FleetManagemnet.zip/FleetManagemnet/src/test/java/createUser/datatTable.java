package createUser;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import browserUtils.browserInitilizer;
import frameworkUtils.reusableComponent;
import seleniumUtils.seleniumActions;

public class datatTable {
	private static final Logger logger = Logger.getLogger(createUser.class);
	@BeforeTest
	public static void launchBrowser() throws Exception
	{
		browserInitilizer.readDriverUtils(reusableComponent.dataTable);
		logger.info("im using the url "  +reusableComponent.dataTable);
	}
	
	
	@Test(priority = 1 )
	public static void handleframe() throws Exception {
	
		seleniumActions.fetchdatafromDataTable();
	
	}
	

	
	@AfterTest
	public void closeBrowser()
	{
		browserInitilizer.driver.close();
	}
}
