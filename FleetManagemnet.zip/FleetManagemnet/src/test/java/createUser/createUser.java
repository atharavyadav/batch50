package createUser;

import org.testng.annotations.Test;

import browser.browserInitilizer;

public class createUser {
	

	@Test
	public static void launchBrowser() throws Exception {
		browserInitilizer.readDriverUtils();
	}
	
	
}
