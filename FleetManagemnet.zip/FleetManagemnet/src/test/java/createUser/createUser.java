package createUser;

import java.rmi.registry.Registry;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import ObjectPropertiesUtils.RegisterOR;
import ObjectPropertiesUtils.readDataFromPropertyFile;
import browserUtils.browserInitilizer;
import excelUtils.readDataFromExcel;

public class createUser {
	

	@Test
	public static void launchBrowser() throws Exception {
		browserInitilizer.readDriverUtils();
		browserInitilizer.driver.findElement(By.xpath(readDataFromPropertyFile.readDataFromORFile("ContactInformation.FirstName.input"))).sendKeys(readDataFromExcel.fetchdatafromExcel(1, 0));
		browserInitilizer.driver.findElement(By.xpath(readDataFromPropertyFile.readDataFromORFile("ContactInformation.lastName.input"))).sendKeys("yadav");
	}
	
	
}
