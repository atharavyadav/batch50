package createUser;


import java.rmi.registry.Registry;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import ObjectPropertiesUtils.RegisterOR;
import ObjectPropertiesUtils.readDataFromPropertyFile;
import browserUtils.browserInitilizer;
import excelUtils.readDataFromExcel;
import frameworkUtils.reusableComponent;
import seleniumUtils.seleniumActions;
@Listeners(listnersUtils.listneres.class)
public class createUser { 
	private static final Logger logger = Logger.getLogger(createUser.class);
	@BeforeTest
	public static void launchBrowser() throws Exception
	{
		browserInitilizer.readDriverUtils(reusableComponent.url);
		logger.info("im using the url "  +reusableComponent.url);
	}
	
	
	@Test(priority = 1 )
	public static void ContactInformation() throws Exception {
		seleniumActions.sendkeys(readDataFromPropertyFile.readDataFromORFile("ContactInformation.FirstName.input"), readDataFromExcel.fetchdatafromExcel(1, 0));
		logger.info("user enters data  " );
		//seleniumActions.takescreeshot("ContactInformation.FirstName");
		seleniumActions.dropdown(readDataFromPropertyFile.readDataFromORFile("MailingInformation.country.select"), "ANGOLA");
		seleniumActions.dropdown(readDataFromPropertyFile.readDataFromORFile("MailingInformation.country.select"), "ANTARCTICA");
       // seleniumActions.click("//input[@name='submit']");
        seleniumActions.fetchalldropdownvalues();
       // seleniumActions.takescreeshot("dropdown");
	 }
	
//	
//	@Test(priority = 2 , dependsOnMethods ="ContactInformation" )
//	public static void MailingInformation() throws Exception {
//		
//		browserInitilizer.driver.findElement(By.xpath(readDataFromPropertyFile.readDataFromORFile("ContactInformation.FirstName.input"))).sendKeys(readDataFromExcel.fetchdatafromExcel(1, 0));
//		browserInitilizer.driver.findElement(By.xpath(readDataFromPropertyFile.readDataFromORFile("ContactInformation.lastName.input"))).sendKeys("yadav");
//	}
//	
//	@Test(priority = 3 , dependsOnMethods ="MailingInformation")
//	public static void  UserInformation() throws Exception {
//		
//		browserInitilizer.driver.findElement(By.xpath(readDataFromPropertyFile.readDataFromORFile("ContactInformation.FirstName.input"))).sendKeys(readDataFromExcel.fetchdatafromExcel(1, 0));
//		browserInitilizer.driver.findElement(By.xpath(readDataFromPropertyFile.readDataFromORFile("ContactInformation.lastName.input"))).sendKeys("yadav");
//	}
	
	@AfterTest
	public void closeBrowser()
	{
		browserInitilizer.driver.close();
	}
}
