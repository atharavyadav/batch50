package createUser;

import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchWindowException;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import ObjectPropertiesUtils.readDataFromPropertyFile;
import browserUtils.browserInitilizer;
import excelUtils.readDataFromExcel;
import frameworkUtils.reusableComponent;
import seleniumUtils.seleniumActions;

public class pagehadle {
	private static final Logger logger = Logger.getLogger(createUser.class);
	@BeforeTest
	public static void launchBrowser() throws Exception
	{
		
			browserInitilizer.readDriverUtils(reusableComponent.pageUrl);
			logger.info("im using the url "  +reusableComponent.pageUrl);
		
		
		
	}	
	
	
	@Test(priority = 1 )
	public static void handleAlert() throws Exception {
		
		
	 }
	

	
	@AfterTest
	public void closeBrowser()
	{
		browserInitilizer.driver.close();
	}
}
