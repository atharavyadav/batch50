package createUser;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import browserUtils.browserInitilizer;
import frameworkUtils.reusableComponent;
import seleniumUtils.seleniumActions;

public class hadleFrame {
	private static final Logger logger = Logger.getLogger(createUser.class);
	@BeforeTest
	public static void launchBrowser() throws Exception
	{
		browserInitilizer.readDriverUtils(reusableComponent.frameurl);
		logger.info("im using the url "  +reusableComponent.frameurl);
	}
	
	
	@Test(priority = 1 )
	public static void handleframe() throws Exception {
		seleniumActions.frameActions("a077aa5e");
		seleniumActions.click("//img[@src='Jmeter720.png']");
	 }
	

	
	@AfterTest
	public void closeBrowser()
	{
		browserInitilizer.driver.close();
	}
}
