package seleniumUtils;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import browserUtils.browserInitilizer;
import net.bytebuddy.asm.Advice.This;

public class seleniumActions {
	
	public static void sendkeys(String xpath, String vaule)
	{
		
	browserInitilizer.driver.findElement(By.xpath(xpath)).sendKeys(vaule);
		
	}
	
	public static void takescreeshot(String name) throws IOException
	{
		
		TakesScreenshot tc = (TakesScreenshot)browserInitilizer.driver;
		File file = tc.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file, new File("D:\\eclipse\\FleetManagemnet\\screenshots\\"+name+".png"));
		
	}
	
	public static void pagination(int pagetoclick) throws IOException
	{
		
		List <WebElement> list =browserInitilizer.driver.findElements(By.xpath("//a[@class='page-numbers']"));
		for (int i = 1; i < list.size(); i++) {
			if (i==pagetoclick) {
				list.get(i).click();
			}
			
		}
		
	}
	
	public static void dropdown(String xpath,String dropdownvaule)
	{
		WebElement ele= browserInitilizer.driver.findElement(By.xpath(xpath));
		Select sel = new Select(ele);
		sel.selectByValue(dropdownvaule);
		
	}
	
	public static void fetchdatafromDataTable()
	{
		List<WebElement> tr = browserInitilizer.driver.findElements(By.xpath("//table[@class='dataTable']//tr"));
		System.out.println("length of the datatable" +tr.size());//25
		for (int i = 1; i<tr.size(); i++) {
			List<WebElement> td	= browserInitilizer.driver.findElements(By.xpath("//table[@class='dataTable']//tr["+i+"]//td"));
			for (int j = 1; j < td.size(); j++) {		
			String CompanyData =browserInitilizer.driver.findElement(By.xpath("//table[@class='dataTable']//tr["+i+"]//td["+j+"]")).getText();
			System.out.println(CompanyData);
			
			}	
		}
		
	}
	
	public static void click(String xpath)
	{
		browserInitilizer.driver.findElement(By.xpath(xpath)).click();
		
	}
	
	public static String alertsActions(boolean flag)
	{
		Alert alert = browserInitilizer.driver.switchTo().alert();
		String msg =alert.getText();
		if (flag==true) {
			alert.accept();
			
		} else {
          alert.dismiss();
		}
		
		return msg;
		
		
	}
	
	
	public static void frameActions(String frameId)
	{
		browserInitilizer.driver.switchTo().frame(frameId);
		
		
	}
	public static void fetchalldropdownvalues()
	{
		
	List<WebElement> list =  browserInitilizer.driver.findElements(By.xpath("//select[@name='country']//option"));
		System.out.println(list.size());
	   for (int i = 1; i < list.size(); i++) {  
		String allvalues = list.get(i).getText();
		System.out.println(allvalues);
		
		
	}
	}
	
	public static void ImplicitWait(int time) throws InterruptedException
	{
		//Thread.sleep(6000);
		browserInitilizer.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(time));
		
	}
	
	public static void ExplictWait(int time , String xpath) throws InterruptedException
	{
		WebDriverWait wait = new WebDriverWait(browserInitilizer.driver, Duration.ofSeconds(time));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		
	}
	
	public static void switToNewWindow() throws InterruptedException
	{
//	WebElement ele = 	browserInitilizer.driver.findElement(By.xpath("//button[@ID='tabButton']"));
//	JavascriptExecutor js = (JavascriptExecutor)browserInitilizer.driver;
//	js.executeScript("arguments[0].scrollIntoView(true)", ele);
//		ele.click();
		
	WebElement ele = browserInitilizer.driver.findElement(By.xpath("//button[@id='windowButton']"));
	JavascriptExecutor js = (JavascriptExecutor)browserInitilizer.driver;
	js.executeScript("arguments[0].scrollIntoView(true)", ele);
	
	
	String parentID = 	browserInitilizer.driver.getWindowHandle();
	System.out.println("parent id" + parentID);
	Set<String> childID=    browserInitilizer.driver.getWindowHandles();
	System.out.println("child id" + childID);
	for (String string : childID) {
		if(!string.equals(parentID))
		{
			browserInitilizer.driver.switchTo().window(string);
			break;
			
		}
	}
	
	String data = browserInitilizer.driver.getTitle();
	System.out.println("title" + data);
	}
	
	public static void uploadFile() throws InterruptedException
	{
	WebElement ele = browserInitilizer.driver.findElement(By.xpath("//input[@id='uploadFile']"));
		File file = new File("D:\\eclipse\\FleetManagemnet\\uploadFile\\data.txt");
		ele.sendKeys(file.getAbsolutePath());
		
		
	}
}
