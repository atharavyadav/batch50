package seleniumUtils;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import browserUtils.browserInitilizer;

public class seleniumActions {
	
	public static void sendkeys(String xpath, String vaule)
	{
		
			browserInitilizer.driver.findElement(By.xpath(xpath)).sendKeys(vaule);
		
	}
	
	public static void takescreeshot(String name) throws IOException
	{
		
		TakesScreenshot tc = (TakesScreenshot)browserInitilizer.driver;
		File file = tc.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(file, new File("D:\\eclipse\\FleetManagemnet\\screenshots\\"+name+".png"));
		
	}
	
	public static void dropdown(String xpath,String dropdownvaule)
	{
		WebElement ele= browserInitilizer.driver.findElement(By.xpath(xpath));
		Select sel = new Select(ele);
		sel.selectByValue(dropdownvaule);
		
	}
	
	public static void click(String xpath)
	{
		browserInitilizer.driver.findElement(By.xpath(xpath)).click();
		
	}
	
	public static void fetchalldropdownvalues()
	{
		
	List<WebElement> list =  browserInitilizer.driver.findElements(By.xpath("//select[@name='country']//option"));
		System.out.println(list.size());
	   for (int i = 1; i < list.size(); i++) {  
		String allvalues = list.get(i).getText();
		System.out.println(allvalues);
		
		
	}
	}
	
	public static void ImplicitWait(int time) throws InterruptedException
	{
		//Thread.sleep(6000);
		browserInitilizer.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(time));
		
	}
	
	public static void ExplictWait(int time , String xpath) throws InterruptedException
	{
		WebDriverWait wait = new WebDriverWait(browserInitilizer.driver, Duration.ofSeconds(time));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		
	}
	

}
