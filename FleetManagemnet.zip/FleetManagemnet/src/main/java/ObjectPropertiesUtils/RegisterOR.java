package ObjectPropertiesUtils;

public interface RegisterOR {

	public static String ContactInformation_FirstName_input = "//input[@name='firstName']";
}
