package excelUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import frameworkUtils.reusableComponent;

public class readDataFromExcel {

	public static String fetchdatafromExcel(int rownum , int column) throws InvalidFormatException, IOException {
		
		File file = new File(reusableComponent.ExcelTestData_path);
		FileInputStream stream  = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(file);
		XSSFSheet sheet = wb.getSheet("FleetManagement");
		String data = sheet.getRow(rownum).getCell(column).getStringCellValue();
		return data;
		
	}
}
