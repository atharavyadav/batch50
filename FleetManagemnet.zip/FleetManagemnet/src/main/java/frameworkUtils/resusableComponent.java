package frameworkUtils;

public interface resusableComponent {
	
	public static String browserType="edge";
	public static String chrome_exte="webdriver.chrome.driver";
	public static String edge_exte="webdriver.edge.driver";
	public static String chrome_path="D:\\eclipse\\FleetManagemnet\\browser\\chromedriver.exe";
	public static String edge_path="D:\\eclipse\\FleetManagemnet\\browser\\msedgedriver.exe";
	public static String url="https://demo.guru99.com/test/newtours/register.php";
}
