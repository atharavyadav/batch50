package frameworkUtils;

public interface reusableComponent {
	
	public static String browserType="chrome";
	public static String chrome_exte="webdriver.chrome.driver";
	public static String edge_exte="webdriver.edge.driver";
	public static String chrome_path="D:\\eclipse\\FleetManagemnet\\browser\\chromedriver.exe";
	public static String edge_path="D:\\eclipse\\FleetManagemnet\\browser\\msedgedriver.exe";
	public static String RegisterOR_path="D:\\eclipse\\FleetManagemnet\\OR\\RegisterOR.properties";
	public static String ExcelTestData_path="D:\\eclipse\\FleetManagemnet\\src\\test\\resources\\InputTestData.xlsx";
	public static String url="https://demo.guru99.com/test/newtours/register.php";
	public static String waiturl="https://www.hyrtutorials.com/p/waits-demo.html";
}
