package frameworkUtils;

public interface reusableComponent {
	
	public static String browserType="chrome";
	public static String chrome_exte="webdriver.chrome.driver";
	public static String edge_exte="webdriver.edge.driver";
	public static String chrome_path="D:\\eclipse\\FleetManagemnet\\browser\\chromedriver.exe";
	public static String edge_path="D:\\eclipse\\FleetManagemnet\\browser\\msedgedriver.exe";
	public static String RegisterOR_path="D:\\eclipse\\FleetManagemnet\\OR\\RegisterOR.properties";
	public static String ExcelTestData_path="D:\\eclipse\\FleetManagemnet\\src\\test\\resources\\InputTestData.xlsx";
	public static String url="https://demo.guru99.com/test/newtours/register.php";
	public static String waiturl="https://www.hyrtutorials.com/p/waits-demo.html";
	public static String alerturl="https://demo.guru99.com/test/delete_customer.php";
	public static String frameurl="https://demo.guru99.com/test/guru99home/";
	public static String dataTable="https://demo.guru99.com/test/web-table-element.php";
	public static String Switch_window_url="https://demoqa.com/browser-windows";
	public static String pageUrl="https://www.scrapingcourse.com/ecommerce/";
	public static String uploadURL="https://www.tutorialspoint.com/selenium/practice/upload-download.php";
}
